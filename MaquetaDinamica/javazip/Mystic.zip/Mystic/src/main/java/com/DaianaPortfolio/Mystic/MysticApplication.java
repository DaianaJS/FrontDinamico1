package com.DaianaPortfolio.Mystic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysticApplication {

	public static void main(String[] args) {
		SpringApplication.run(MysticApplication.class, args);
	}

}
