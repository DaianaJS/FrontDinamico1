package com.DaianaPortfolio.Mystic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MysticApplicationTests {

	@Test
	void contextLoads() {
	}

}
